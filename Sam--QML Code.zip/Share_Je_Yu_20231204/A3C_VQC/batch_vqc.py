

import pickle

# Plotting
import matplotlib.pyplot as plt

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
# from torch.optim import lr_scheduler
# import torchvision
# from torchvision import datasets, models, transforms

# Pennylane
import pennylane as qml
from pennylane import numpy as np

# sklearn
from sklearn.preprocessing import StandardScaler

# Other tools
import time
import os
import copy
from datetime import datetime

# metaQuantum
from metaquantum.CircuitComponents import *


class BatchVQCTorch(nn.Module):
	def __init__(self, input_dim, output_dim, num_qubit, num_vqc_layers, dev, hadamard_gate, more_entangle):
		super().__init__()

		self.input_dim = input_dim
		self.output_dim = output_dim
		self.num_qubit = num_qubit
		self.num_vqc_layers = num_vqc_layers
		self.dev = dev
		self.hadamard_gate = hadamard_gate
		self.more_entangle = more_entangle

		self.qdevice = "default.qubit" # Should be removed later
		self.gpu_q = False # Should be removed later

		self.q_params = nn.Parameter(0.01 * torch.randn(self.num_vqc_layers, self.num_qubit, 3))

		self.vqc = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.input_dim,
			num_of_output= self.output_dim,
			num_of_wires = self.num_qubit,
			num_of_layers = self.num_vqc_layers,
			qdevice = self.qdevice,
			hadamard_gate = self.hadamard_gate,
			more_entangle = self.more_entangle,
			gpu = self.gpu_q,
			noisy_dev = self.dev)

	def get_angles_atan(self, in_x):
		return torch.stack([torch.stack([torch.atan(item), torch.atan(item**2)]) for item in in_x])

	def forward(self, batch_item):

		self.vqc.var_Q_circuit = self.q_params
		score_batch = []

		for single_item in batch_item:
			res_temp = self.get_angles_atan(single_item)
			# print(res_temp)

			q_out_elem = self.vqc.forward(res_temp)

			# print(q_out_elem)
		
			clamp = 1e-9 * torch.ones(self.output_dim)
			# clamp = 1e-9 * torch.ones(2)
			normalized_output = torch.max(q_out_elem, clamp)
			score_batch.append(normalized_output)

		scores = torch.stack(score_batch).view(len(batch_item),self.output_dim)

		return scores.float()







def main():

	input_dim = 4
	output_dim = 4
	num_qubit = 4
	num_vqc_layers = 2
	dev = qml.device("default.qubit", wires = num_qubit)
	hadamard_gate = True
	more_entangle = False

	model = BatchVQCTorch(
		input_dim = input_dim, 
		output_dim = output_dim, 
		num_qubit = num_qubit, 
		num_vqc_layers = num_vqc_layers, 
		dev = dev, 
		hadamard_gate = hadamard_gate, 
		more_entangle = more_entangle)

	test_input = torch.randn(10, 4)

	res = model.forward(test_input)

	print(res)

	return


if __name__ == '__main__':
	main()