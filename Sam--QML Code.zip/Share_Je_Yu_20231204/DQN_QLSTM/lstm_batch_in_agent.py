# 2022 08 24
# QLSTM in an agent

#####

# Plotting
import matplotlib.pyplot as plt

# Saving
import pickle

# Datetime
from datetime import datetime

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
# from torch.optim import lr_scheduler
# import torchvision
# from torchvision import datasets, models, transforms

# Pennylane
import pennylane as qml
from pennylane import numpy as np


# Other tools
import time
import os
import copy
import random
import gym

# from VQC_GRAD_META_CONSTRUCT import load_JET_4_var_two

from metaquantum.CircuitComponents import *
from metaquantum import Optimization

# QLSTM batch
from lstm_base_class import VQLSTM
from lstm_batch_base_class import BatchVQLSTM



#####
# VQLSTM Core



# Q_network
class Q_net(nn.Module):
	def __init__(self, 
		state_space=None, 
		action_space=None, 
		qrnn_core = None,
		qrnn_hidden_space_h = None,
		qrnn_hidden_space_c = None):
		super(Q_net, self).__init__()

		# space size check
		assert state_space is not None, "None state_space input: state_space should be selected."
		assert action_space is not None, "None action_space input: action_space should be selected."

		assert qrnn_core is not None, "None qrnn_core input: rnn_core should be provided."

		assert qrnn_hidden_space_h is not None, "None qrnn_hidden_space_h input: qrnn_hidden_space_h should be provided."
		assert qrnn_hidden_space_c is not None, "None qrnn_hidden_space_c input: qrnn_hidden_space_c should be provided."

		# self.hidden_space = 64
		self.state_space = state_space
		self.action_space = action_space

		self.hidden_space_h = qrnn_hidden_space_h
		self.hidden_space_c = qrnn_hidden_space_c 
		# 2022 08 25: This is temporary
		# The hidden here is actually the "input" for QLSTM
		# Here we set to be the QLSTM h and c as well

		self.Linear1 = nn.Linear(self.state_space, self.hidden_space_h)

		# 2022 08 24: Should change to QLSTM Batch version
		self.lstm    = qrnn_core

		self.Linear2 = nn.Linear(self.hidden_space_h, self.action_space)

	def forward(self, x, h, c):
		x = F.relu(self.Linear1(x))

		# 2022 08 24: Should change to QLSTM Batch version
		# Current QLSTM only outputs batch of h and c
		h_for_all_steps, (new_h, new_c) = self.lstm(x,h,c)

		# print("SHAPE new_h: ", new_h.shape)
		# print("SHAPE new_c: ", new_c.shape)

		x = self.Linear2(h_for_all_steps)
		return x, new_h, new_c

	def sample_action(self, obs, h,c, epsilon):
		output = self.forward(obs, h,c)

		if random.random() < epsilon:
			return random.randint(0,1), output[1], output[2]
		else:
			return output[0].argmax().item(), output[1] , output[2]
	
	def init_hidden_state(self, batch_size, training=None):

		assert training is not None, "training step parameter should be dtermined"

		if training is True:
			return torch.zeros([1, batch_size, self.hidden_space_h]), torch.zeros([1, batch_size, self.hidden_space_c])
		else:
			return torch.zeros([1, 1, self.hidden_space_h]), torch.zeros([1, 1, self.hidden_space_c])




def main():

	

	# Set gym environment
	env_name = "CartPole-v1"
	env = gym.make(env_name)

	# Set parameters
	batch_size = 8
	epsilon = 0.1
	num_episodes = 20
	max_step = 1000

	# Create BatchVQLSTM

	duplicate_time_of_input = 1 # no use for QLSTM
	lstm_input_size = 4
	lstm_hidden_size = 4
	lstm_cell_cat_size = lstm_input_size + lstm_hidden_size
	lstm_internal_size = 8
	lstm_output_size = 4  # 2022 07 07: the output here is subject to classical layer precessing
	lstm_cell_num_layers = 4 # Original: 2 layers
	lstm_num_qubit = 8

	gpu_q = False # No use here
	qdevice = "default.qubit" # No use here

	as_reservoir = False
	use_qiskit_noise_model = False
	dev = qml.device("default.qubit", wires = lstm_num_qubit)

	model = VQLSTM(lstm_input_size = lstm_input_size, 
		lstm_hidden_size = lstm_hidden_size,
		lstm_output_size = lstm_output_size,
		lstm_num_qubit = lstm_num_qubit,
		lstm_cell_cat_size = lstm_cell_cat_size,
		lstm_cell_num_layers = lstm_cell_num_layers,
		lstm_internal_size = lstm_internal_size,
		duplicate_time_of_input = duplicate_time_of_input,
		as_reservoir = as_reservoir,
		single_y = False,
		output_all_h = True,
		qdevice = qdevice,
		dev = dev,
		gpu_q = gpu_q)

	batch_model = BatchVQLSTM(vqlstm_model = model)


	# Define the Q model

	Q = Q_net(state_space=env.observation_space.shape[0], 
		action_space=env.action_space.n,
		qrnn_core = batch_model,
		qrnn_hidden_space_h = lstm_hidden_size,
		qrnn_hidden_space_c = lstm_internal_size).double()

	# Looking into the h and c
	h, c = Q.init_hidden_state(batch_size=batch_size, training=False)

	print("ROLLING OUT STAGE h: ", h)
	print("ROLLING OUT STAGE h shape: ", h.shape)
	print("ROLLING OUT STAGE c: ", c)
	print("ROLLING OUT STAGE c shape: ", c.shape)

	# Test the env
	s = env.reset()
	print("OBS: ", s)
	print("OBS: ", torch.from_numpy(s).unsqueeze(0))
	print("OBS: ", torch.from_numpy(s).unsqueeze(0).unsqueeze(0))

	print("OBS shape: ", torch.from_numpy(s).unsqueeze(0).unsqueeze(0).shape)

	print(torch.from_numpy(s).unsqueeze(0).unsqueeze(0).dtype)

	a, h, c = Q.sample_action(torch.from_numpy(s).double().unsqueeze(0).unsqueeze(0), 
		h, 
		c, 
		epsilon)

	print("ACTION a: ", a)
	print("AFTER A STEP h: ", h)
	print("AFTER A STEP c: ", c)

	print("AFTER A STEP h shape: ", h.shape)
	print("AFTER A STEP c sahpe: ", c.shape)

	print("START ROLLING OUT...")

	for episode in range(num_episodes):

		done = False
		episode_score = 0

		s = env.reset()
		obs = s
		h, c = Q.init_hidden_state(batch_size=batch_size, training=False)

		for t in range(max_step):
			a, h, c = Q.sample_action(torch.from_numpy(obs).double().unsqueeze(0).unsqueeze(0), h, c, epsilon)
			s_next, r, done, _ = env.step(a)
			
			obs = s_next
			episode_score += r

			if done:
				print("EPISODE {} with SCORE {}".format(episode, episode_score))
				break



	return

if __name__ == '__main__':
	main()


