# 2022 07 19
# IBM Qiskit noise model from WF-IBM JDA notebook

import numpy as np
import matplotlib.pyplot as plt
import pickle
from qiskit.tools.monitor import job_monitor
from qiskit.circuit import gate
from qiskit.providers.aer import noise, AerSimulator, QasmSimulator
from qiskit.visualization import plot_histogram
from qiskit.compiler import transpile, assemble
from qiskit import (QuantumCircuit, ClassicalRegister, QuantumRegister, 
                    execute, BasicAer, IBMQ, Aer)
from qiskit.utils import QuantumInstance


def noisy_backend(backend_type='Qasm'):
	"""
	returns QuantumInstance
	hardcoded function for now
	backend_type is "q" for Qasm or "a" for Aer
	"""
	# Error probabilities
	# rough averages from FakeMelbourne backend noise model
	prob_1 = 0.001     # 1-qubit gate
	prob_2 = 0.03      # 2-qubit CX gate

	# Depolarizing quantum errors
	error_1 = noise.depolarizing_error(prob_1, 1)
	error_2 = noise.depolarizing_error(prob_2, 2)
	

	noise_model = noise.NoiseModel()
	# Include gate errors
	noise_model.add_all_qubit_quantum_error(error_1, ['u1', 'u2', 'u3'])
	noise_model.add_all_qubit_quantum_error(error_1, ['u1', 'u2', 'u3'])
	
	noise_model.add_all_qubit_quantum_error(error_2, ['cx'])
	
	# Get basis gates from noise model
	basis_gates = noise_model.basis_gates
	
	if backend_type == 'Qasm':
		backend = QasmSimulator(noise_model=noise_model, basis_gates=basis_gates)
	elif backend_type == 'Aer':
		pass
	
	return backend


def thermal_noise_backend(num_qubits, return_noise_model = True):
	#https://qiskit.org/documentation/tutorials/simulators/3_building_noise_models.html
	thermal_relaxation_error = noise.thermal_relaxation_error
	# T1 and T2 values for num_qubits
	T1s = np.random.normal(50e3, 10e3, num_qubits) # Sampled from normal distribution mean 50 microsec
	T2s = np.random.normal(70e3, 10e3, num_qubits)  # Sampled from normal distribution mean 50 microsec

	# Truncate random T2s <= T1s
	T2s = np.array([min(T2s[j], 2 * T1s[j]) for j in range(num_qubits)])

	# Instruction times (in nanoseconds)
	time_u1 = 0   # virtual gate
	time_u2 = 50  # (single X90 pulse)
	time_u3 = 100 # (two X90 pulses)
	time_cx = 300
	time_reset = 1000  # 1 microsecond
	time_measure = 1000 # 1 microsecond

	# QuantumError objects
	errors_reset = [thermal_relaxation_error(t1, t2, time_reset) for t1, t2 in zip(T1s, T2s)]
	errors_measure = [thermal_relaxation_error(t1, t2, time_measure) for t1, t2 in zip(T1s, T2s)]
	errors_u1  = [thermal_relaxation_error(t1, t2, time_u1) for t1, t2 in zip(T1s, T2s)]
	errors_u2  = [thermal_relaxation_error(t1, t2, time_u2) for t1, t2 in zip(T1s, T2s)]
	errors_u3  = [thermal_relaxation_error(t1, t2, time_u3) for t1, t2 in zip(T1s, T2s)]
	errors_cx = [[thermal_relaxation_error(t1a, t2a, time_cx).expand(thermal_relaxation_error(t1b, t2b, time_cx))
				  for t1a, t2a in zip(T1s, T2s)]
				   for t1b, t2b in zip(T1s, T2s)]

	# Add errors to noise model
	noise_thermal = noise.NoiseModel()
	
	for j in range(num_qubits):
		noise_thermal.add_quantum_error(errors_reset[j], "reset", [j])
		noise_thermal.add_quantum_error(errors_measure[j], "measure", [j])
		noise_thermal.add_quantum_error(errors_u1[j], "u1", [j])
		noise_thermal.add_quantum_error(errors_u2[j], "u2", [j])
		noise_thermal.add_quantum_error(errors_u3[j], "u3", [j])
		for k in range(num_qubits):
			noise_thermal.add_quantum_error(errors_cx[j][k], "cx", [j, k])
	
	# Get basis gates from noise model
	basis_gates = noise_thermal.basis_gates
	
	if not return_noise_model:
		backend = QasmSimulator(noise_model=noise_thermal, basis_gates=basis_gates)
		
		return backend
	else:
		return noise_thermal


def combined_error_noisy_backend(num_qubits, return_noise_model = True):
	'''1 and 2 qubit gate errors consisting of a depolarizing_error()
	followed by a thermal_relaxation_error().'''
	#https://qiskit.org/documentation/stubs/qiskit.providers.aer.noise.NoiseModel.from_backend.html#qiskit.providers.aer.noise.NoiseModel.from_backend
	#https://qiskit.org/documentation/tutorials/simulators/3_building_noise_models.html
	#thermal_relaxation_error = noise.thermal_relaxation_error
	# T1 and T2 values for num_qubits
	T1s = np.random.normal(50e3, 10e3, num_qubits) # Sampled from normal distribution mean 50 microsec
	T2s = np.random.normal(70e3, 10e3, num_qubits)  # Sampled from normal distribution mean 50 microsec

	# Truncate random T2s <= T1s
	T2s = np.array([min(T2s[j], 2 * T1s[j]) for j in range(num_qubits)])
	
	# Depolarization
	# Error probabilities
	prob_1 = 0.001     # 1-qubit gate
	prob_2 = 0.03      # 2-qubit CX gate

	# Instruction times (nanoseconds)
	time_u1 = 0           # virtual gate
	time_u2 = 50          # (single X90 pulse)
	time_u3 = 100         # (two X90 pulses)
	time_cx = 300
	time_reset = 1000     # 1 microsecond
	time_measure = 1000   # 1 microsecond

	# QuantumError objects
	errors_reset = [noise.thermal_relaxation_error(t1, t2, time_reset) for t1, t2 in zip(T1s, T2s)]
	errors_measure = [noise.thermal_relaxation_error(t1, t2, time_measure) for t1, t2 in zip(T1s, T2s)]
	
	# QuantumError for gates
	errors_u1  = [noise.depolarizing_error(prob_1, 1).compose(noise.thermal_relaxation_error(t1, t2, time_u1))
				  for t1, t2 in zip(T1s, T2s)]
	errors_u2  = [noise.depolarizing_error(prob_1, 1).compose(noise.thermal_relaxation_error(t1, t2, time_u2))
				  for t1, t2 in zip(T1s, T2s)]
	errors_u3  = [noise.depolarizing_error(prob_1, 1).compose(noise.thermal_relaxation_error(t1, t2, time_u3))
				  for t1, t2 in zip(T1s, T2s)]
	errors_cx = [[(noise.depolarizing_error(prob_1, 1).compose(noise.thermal_relaxation_error(t1a, t2a, time_cx)).expand(
				 noise.depolarizing_error(prob_1, 1).compose(noise.thermal_relaxation_error(t1b, t2b, time_cx))))
				  for t1a, t2a in zip(T1s, T2s)]
				   for t1b, t2b in zip(T1s, T2s)]
															  
	
	# Add errors to noise model
	noise_thermal = noise.NoiseModel()
	for j in range(num_qubits):
		noise_thermal.add_quantum_error(errors_reset[j], "reset", [j])
		noise_thermal.add_quantum_error(errors_measure[j], "measure", [j])
		
		noise_thermal.add_quantum_error(errors_u1[j], "u1", [j])
		noise_thermal.add_quantum_error(errors_u2[j], "u2", [j])
		noise_thermal.add_quantum_error(errors_u3[j], "u3", [j])
		for k in range(num_qubits):
			noise_thermal.add_quantum_error(errors_cx[j][k], "cx", [j, k])
	
	# Get basis gates from noise model
	basis_gates = noise_thermal.basis_gates
	
	if not return_noise_model:
		backend = QasmSimulator(noise_model=noise_thermal, basis_gates=basis_gates)
		
		return backend
	else:
		return noise_thermal



def combined_noise_backend_normdist(num_qubits, return_noise_model = True):
	'''1 and 2 qubit gate errors consisting of a depolarizing_error()
	followed by a thermal_relaxation_error().'''
	#https://qiskit.org/documentation/stubs/qiskit.providers.aer.noise.NoiseModel.from_backend.html#qiskit.providers.aer.noise.NoiseModel.from_backend
	#https://qiskit.org/documentation/tutorials/simulators/3_building_noise_models.html
	
	therm_err = noise.thermal_relaxation_error
	depol_err = noise.depolarizing_error
	
	# T1 and T2 values for num_qubits
	T1s = np.random.normal(50e3, 10e3, num_qubits) # Sampled from normal distribution mean 50 microsec
	T2s = np.random.normal(70e3, 10e3, num_qubits)  # Sampled from normal distribution mean 50 microsec

	# Truncate random T2s <= T1s
	T2s = np.array([min(T2s[j], 2 * T1s[j]) for j in range(num_qubits)])
	
	# Depolarization
	# Error probabilities
	probs_1 = np.random.normal(0.001, 0.0005, num_qubits)
	probs_2 = np.random.normal(0.03, 0.005, num_qubits)
	
	#prob_1 = 0.001     # 1-qubit gate
	#prob_2 = 0.03      # 2-qubit CX gate

	# Instruction times (in nanoseconds)
	time_u1 = 0   # virtual gate
	time_u2 = 50  # (single X90 pulse)
	time_u3 = 100 # (two X90 pulses)
	time_cx = 300
	time_reset = 1000  # 1 microsecond
	time_measure = 1000 # 1 microsecond

	# QuantumError objects
	errors_reset = [therm_err(t1, t2, time_reset) for t1, t2 in zip(T1s, T2s)]
	errors_measure = [therm_err(t1, t2, time_measure) for t1, t2 in zip(T1s, T2s)]
	
	# QuantumError for gates
	errors_u1  = [depol_err(prob_1, 1).compose(therm_err(t1, t2, time_u1))
				  for prob_1, t1, t2 in zip(probs_1, T1s, T2s)]
	errors_u2  = [depol_err(prob_1, 1).compose(therm_err(t1, t2, time_u2))
				  for prob_1, t1, t2 in zip(probs_1, T1s, T2s)]
	errors_u3  = [depol_err(prob_1, 1).compose(therm_err(t1, t2, time_u3))
				  for prob_1, t1, t2 in zip(probs_1, T1s, T2s)]
	
	errors_cx = [
		[depol_err(prob_2, 1).compose((therm_err(t1a, t2a, time_cx).expand(therm_err(t1b, t2b, time_cx)))) for prob_2, t1a, t2a in zip(probs_2, T1s, T2s)]
		for prob_2, t1b, t2b in zip(probs_2, T1s, T2s)]
												 
	
	# Add errors to noise model
	noise_thermal = noise.NoiseModel()
	# add errors to gates
	for j in range(num_qubits):
		noise_thermal.add_quantum_error(errors_reset[j], "reset", [j])
		noise_thermal.add_quantum_error(errors_measure[j], "measure", [j])
		
		noise_thermal.add_quantum_error(errors_u1[j], "u1", [j])
		noise_thermal.add_quantum_error(errors_u2[j], "u2", [j])
		noise_thermal.add_quantum_error(errors_u3[j], "u3", [j])
		for k in range(num_qubits):
			noise_thermal.add_quantum_error(errors_cx[j][k], "cx", [j, k])
	
	# Get basis gates from noise model
	basis_gates = noise_thermal.basis_gates
	
	if not return_noise_model:
		backend = QasmSimulator(noise_model=noise_thermal, basis_gates=basis_gates)
		
		return backend
	else:
		return noise_thermal
