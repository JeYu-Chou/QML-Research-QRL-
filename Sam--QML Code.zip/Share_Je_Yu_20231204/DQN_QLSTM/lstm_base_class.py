# 2022 08 24
# QLSTM base class for DeepVQRNN


# Plotting
import matplotlib.pyplot as plt

# Saving
import pickle

# Datetime
from datetime import datetime

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
# from torch.optim import lr_scheduler
# import torchvision
# from torchvision import datasets, models, transforms

# Pennylane
import pennylane as qml
from pennylane import numpy as np

# sklearn
from sklearn.preprocessing import StandardScaler

# Other tools
import time
import os
import copy

# from VQC_GRAD_META_CONSTRUCT import load_JET_4_var_two

from metaquantum.CircuitComponents import *
from metaquantum import Optimization

# Qiskit
import qiskit
import qiskit.providers.aer.noise as noise

# Custom qiskit noise model
from ibm_noise_models import thermal_noise_backend, combined_error_noisy_backend, combined_noise_backend_normdist


# Dataset
# from generate_lstm_dataset import get_sine_data
# from data.load_air_passengers import get_air_passenger_data_single_predict
# from data.damped_shm import get_damped_shm_data
from data.bessel_functions import get_bessel_data
# from data.delayed_quantum_control import get_delayed_quantum_control_data
# from data.population_inversion_revised import get_population_inversion_data
# from generate_lstm_dataset import get_sine_data_single_predict
# from data.narma_data_set import get_narma2_data
# from data.narma_generator import get_narma_data

##
# Device auto select
# dtype = torch.cuda.DoubleTensor if torch.cuda.is_available() else torch.DoubleTensor
# device = 'cuda' if torch.cuda.is_available() else 'cpu'



##
# 2022 08 09
# Improved and modularized, different from the previous VQRNN. VQGRU, VQLSTM
# Avoid the use of global variable

class VQLSTM(nn.Module):
	def __init__(self, 
		lstm_input_size, 
		lstm_hidden_size,
		lstm_output_size,
		lstm_num_qubit,
		lstm_cell_cat_size,
		lstm_cell_num_layers,
		lstm_internal_size,
		duplicate_time_of_input,
		as_reservoir,
		single_y,
		output_all_h,
		qdevice,
		dev,
		gpu_q):
		# Need respective VQ cells and parameter
		# Probably modity to torch style nn.Module
		super().__init__()

		self.lstm_input_size = lstm_input_size
		self.lstm_hidden_size = lstm_hidden_size
		self.lstm_output_size = lstm_output_size
		self.lstm_num_qubit = lstm_num_qubit
		self.lstm_cell_cat_size = lstm_cell_cat_size
		self.lstm_cell_num_layers = lstm_cell_num_layers
		self.lstm_internal_size = lstm_internal_size
		self.duplicate_time_of_input = duplicate_time_of_input
		self.as_reservoir = as_reservoir
		self.single_y = single_y
		self.output_all_h = output_all_h

		self.qdevice = qdevice
		self.dev = dev
		self.gpu_q = gpu_q
		
		
		# self.q_params_1 = nn.Parameter(0.01 * torch.randn(self.rnn_cell_num_layers, self.rnn_num_qubit, 3))
		self.q_params_1 = nn.Parameter(0.01 * torch.randn(self.lstm_cell_num_layers, self.lstm_num_qubit, 3))
		self.q_params_2 = nn.Parameter(0.01 * torch.randn(self.lstm_cell_num_layers, self.lstm_num_qubit, 3))
		self.q_params_3 = nn.Parameter(0.01 * torch.randn(self.lstm_cell_num_layers, self.lstm_num_qubit, 3))
		self.q_params_4 = nn.Parameter(0.01 * torch.randn(self.lstm_cell_num_layers, self.lstm_num_qubit, 3))
		self.q_params_5 = nn.Parameter(0.01 * torch.randn(self.lstm_cell_num_layers, self.lstm_num_qubit, 3))
		self.q_params_6 = nn.Parameter(0.01 * torch.randn(self.lstm_cell_num_layers, self.lstm_num_qubit, 3))

		if self.as_reservoir:
			self.q_params_1.requires_grad = False
			self.q_params_2.requires_grad = False
			self.q_params_3.requires_grad = False
			self.q_params_4.requires_grad = False
			self.q_params_5.requires_grad = False
			self.q_params_6.requires_grad = False
		
		# 2022 08 24: This part is dated compared to RNN and GRU
		# self.classical_nn_linear = nn.Linear(self.lstm_hidden_size, self.lstm_output_size)
		self.classical_nn_linear = nn.Linear(self.lstm_output_size, 1)

		# 2022 07 21
		# Adding Qiskit noise simulation
		# VQCVariationalLoadingFlexNoisy is a new module in metaquantum.
		self.cell_1 = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.lstm_cell_cat_size,
			num_of_output= self.lstm_internal_size,
			num_of_wires = 4,
			num_of_layers = self.lstm_cell_num_layers,
			qdevice = self.qdevice,
			hadamard_gate = True,
			more_entangle = True,
			gpu = self.gpu_q,
			noisy_dev = self.dev)
		self.cell_2 = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.lstm_cell_cat_size,
			num_of_output= self.lstm_internal_size,
			num_of_wires = 4,
			num_of_layers = self.lstm_cell_num_layers,
			qdevice = self.qdevice,
			hadamard_gate = True,
			more_entangle = True,
			gpu = self.gpu_q,
			noisy_dev = dev)
		self.cell_3 = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.lstm_cell_cat_size,
			num_of_output= self.lstm_internal_size,
			num_of_wires = 4,
			num_of_layers = self.lstm_cell_num_layers,
			qdevice = self.qdevice,
			hadamard_gate = True,
			more_entangle = True,
			gpu = self.gpu_q,
			noisy_dev = self.dev)
		self.cell_4 = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.lstm_cell_cat_size,
			num_of_output= self.lstm_internal_size,
			num_of_wires = 4,
			num_of_layers = self.lstm_cell_num_layers,
			qdevice = self.qdevice,
			hadamard_gate = True,
			more_entangle = True,
			gpu = self.gpu_q,
			noisy_dev = self.dev)
		# Transform into h_t
		self.cell_5 = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.lstm_internal_size,
			num_of_output= self.lstm_hidden_size,
			num_of_wires = 4,
			num_of_layers = self.lstm_cell_num_layers,
			qdevice = self.qdevice,
			hadamard_gate = True,
			more_entangle = True,
			gpu = self.gpu_q,
			noisy_dev = self.dev)
		# Transform into output
		self.cell_6 = VQCVariationalLoadingFlexNoisy(
			num_of_input= self.lstm_internal_size,
			num_of_output= self.lstm_output_size,
			num_of_wires = 4,
			num_of_layers = self.lstm_cell_num_layers,
			qdevice = self.qdevice,
			hadamard_gate = True,
			more_entangle = True,
			gpu = self.gpu_q,
			noisy_dev = self.dev)
		

	def get_angles_atan(self, in_x):
		return torch.stack([torch.stack([torch.atan(item), torch.atan(item**2)]) for item in in_x])

	def _forward(self, single_item_x, single_item_h, single_item_c):
		# for the single item input
		self.cell_1.var_Q_circuit = self.q_params_1
		self.cell_2.var_Q_circuit = self.q_params_2
		self.cell_3.var_Q_circuit = self.q_params_3
		self.cell_4.var_Q_circuit = self.q_params_4
		self.cell_5.var_Q_circuit = self.q_params_5
		self.cell_6.var_Q_circuit = self.q_params_6

		# 2022 07 11: Duplicate the input
		single_item_x = torch.cat([single_item_x for i in range(self.duplicate_time_of_input)])
		cat = torch.cat([single_item_x, single_item_h])
		# print("cat: ", cat)

		res_temp = self.get_angles_atan(cat)
		# print("res_temp: ", res_temp)

		# Go through the four circuit
		res_from_cell_1 = self.cell_1.forward(res_temp)
		act_1 = nn.Sigmoid()
		res_from_cell_1 = act_1(res_from_cell_1)
		# print("res_from_cell_1: ", res_from_cell_1)
		res_from_cell_2 = self.cell_2.forward(res_temp)
		act_2 = nn.Sigmoid()
		res_from_cell_2 = act_2(res_from_cell_2)
		# print("res_from_cell_2: ", res_from_cell_2)
		res_from_cell_3 = self.cell_3.forward(res_temp)
		act_3 = nn.Tanh()
		res_from_cell_3 = act_3(res_from_cell_3)
		# print("res_from_cell_3: ", res_from_cell_3)
		res_from_cell_4 = self.cell_4.forward(res_temp)
		act_4 = nn.Sigmoid()
		res_from_cell_4 = act_4(res_from_cell_4)
		# print("res_from_cell_4: ", res_from_cell_4)

		# Go through several element-wise operations as the classical counterpart

		res_2_mul_3 = torch.mul(res_from_cell_2, res_from_cell_3)
		res_c = torch.mul(single_item_c, res_from_cell_1)
		c_t = torch.add(res_c, res_2_mul_3) # return this updated cell state C_t
		h_t = self.cell_5.forward(self.get_angles_atan(torch.mul(res_from_cell_4, torch.tanh(c_t)))) # return this h_t
		# out = self.classical_final_scaling[0] * self.cell_6.forward(self.get_angles_atan(torch.mul(res_from_cell_4, torch.tanh(c_t)))) + self.classical_final_scaling[1]
		
		# 2022 07 07: For reservoir computing, we need to change here to a nn.Linear layer.
		cell_6_res = self.cell_6.forward(self.get_angles_atan(torch.mul(res_from_cell_4, torch.tanh(c_t))))
		# out = self.classical_final_scaling[0] * self.cell_6.forward(self.get_angles_atan(torch.mul(res_from_cell_4, torch.tanh(c_t)))) + self.classical_final_scaling[1]
		# print(cell_6_res)
		out = self.classical_nn_linear.forward(cell_6_res)

		return h_t, c_t, out

	def forward(self, input_sequence_x, initial_h, initial_c):
		# The input is a sequence and initial h_t c_t
		# return a sequence

		# 2022 08 09
		# Need to consider the situation when we need to output all h



		h = initial_h.clone().detach()
		c = initial_c.clone().detach()

		seq = []

		h_history = [] # 2022 08 09: This is for the Deep RNN use. The hidden values is fed to the next layer of RNN
		c_history = [] # 2022 08 24: This is for QLSTM only.

		for item in input_sequence_x:
			h, c, out = self._forward(item, h, c)
			h_history.append(h)
			c_history.append(c)
			# print(h)
			# print(c)
			# print(out)

			seq.append(out)

		if self.output_all_h:
			# 2022 08 09: This is the h output for Deep RNN.
			return torch.stack(h_history), torch.stack(c_history)
		else:

			# 2022 08 09: This is the original single y output.
			return seq[-1]





def main():

	# Basic settings:

	# Force to use CPU
	dtype = torch.DoubleTensor
	device = 'cpu'


	qdevice = "default.qubit" # 2022 07 21: Should be depreciated later
	# qdevice = "qulacs.simulator"

	# gpu_q = True
	gpu_q = False

	##
	duplicate_time_of_input = 1

	lstm_input_size = 1
	lstm_hidden_size = 3
	lstm_cell_cat_size = lstm_input_size + lstm_hidden_size
	lstm_internal_size = 4
	lstm_output_size = 4  # 2022 07 07: the output here is subject to classical layer precessing
	lstm_cell_num_layers = 4 # Original: 2 layers
	lstm_num_qubit = 4

	as_reservoir = False
	# 2022 07 12: switch for reservoir -> if True, then the QRNN parameters will not be updated


	# 2022 07 21
	# Adding Qiskit noise simulation
	use_qiskit_noise_model = False

	##

	# 2022 07 21
	# Adding Qiskit noise simulation
	dev = None

	if use_qiskit_noise_model:
		# Call the noise model
		noise_model = combined_noise_backend_normdist(num_qubits = lstm_num_qubit)
		dev = qml.device('qiskit.aer', wires=lstm_num_qubit, noise_model=noise_model)

	else:
		dev = qml.device("default.qubit", wires = lstm_num_qubit)


	# Initialize the model
	model = VQLSTM(lstm_input_size = lstm_input_size, 
		lstm_hidden_size = lstm_hidden_size,
		lstm_output_size = lstm_output_size,
		lstm_num_qubit = lstm_num_qubit,
		lstm_cell_cat_size = lstm_cell_cat_size,
		lstm_cell_num_layers = lstm_cell_num_layers,
		lstm_internal_size = lstm_internal_size,
		duplicate_time_of_input = duplicate_time_of_input,
		as_reservoir = as_reservoir,
		single_y = False,
		output_all_h = True,
		qdevice = qdevice,
		dev = dev,
		gpu_q = gpu_q).double()

	# Load the data

	x, y = get_bessel_data()

	num_for_train_set = int(0.67 * len(x))

	x_train = x[:num_for_train_set].type(dtype)
	y_train = y[:num_for_train_set].type(dtype)

	x_test = x[num_for_train_set:].type(dtype)
	y_test = y[num_for_train_set:].type(dtype)

	print("x_train: ", x_train)
	print("x_test: ", x_test)

	# Test run the single layer VQ-LSTM

	h_0 = torch.zeros(lstm_hidden_size,).type(dtype)
	c_0 = torch.zeros(lstm_internal_size,).type(dtype)

	print("First data: ", x_train[0])
	print("First target: ", y_train[0])
	first_run_h, first_run_c = model.forward(x_train[0].reshape(4,1), h_0, c_0)
	print("Output of first_run_h: ", first_run_h)
	print("Output of first_run_c: ", first_run_c)

	# Consider the input with more than one dimension

	lstm_input_size = 3
	lstm_hidden_size = 1
	lstm_cell_cat_size = lstm_input_size + lstm_hidden_size
	lstm_internal_size = 4
	lstm_output_size = 4
	lstm_cell_num_layers = 4 # Original: 2 layers
	lstm_num_qubit = 4

	model_2 = VQLSTM(lstm_input_size = lstm_input_size, 
		lstm_hidden_size = lstm_hidden_size,
		lstm_output_size = lstm_output_size,
		lstm_num_qubit = lstm_num_qubit,
		lstm_cell_cat_size = lstm_cell_cat_size,
		lstm_cell_num_layers = lstm_cell_num_layers,
		lstm_internal_size = lstm_internal_size,
		duplicate_time_of_input = duplicate_time_of_input,
		as_reservoir = as_reservoir,
		single_y = False,
		output_all_h = True,
		qdevice = qdevice,
		dev = dev,
		gpu_q = gpu_q).double()

	test_input = torch.zeros(4,3).type(dtype)
	first_run_h, first_run_c = model_2.forward(test_input, h_0, c_0)
	print("Output of model_2 first_run_h: ", first_run_h)
	print("Output Shape of model_2 first_run_h: ", first_run_h.shape)

	print("Output of model_2 first_run_c: ", first_run_c)
	print("Output Shape of model_2 first_run_c: ", first_run_c.shape)

	# Test the output from model_1
	res_from_model_1_h, res_from_model_1_c = model.forward(x_train[0].reshape(4,1), h_0, c_0)
	print("Output of MODEL 1 h: ", res_from_model_1_h)
	print("Output Shape of MODEL 1 h: ", res_from_model_1_h.shape)

	print("Output of MODEL 1 c: ", res_from_model_1_c)
	print("Output Shape of MODEL 1 c: ", res_from_model_1_c.shape)

	second_run_h, second_run_c = model_2.forward(res_from_model_1_h, h_0, c_0)
	print("Output of (SENDING H FROM MODEL 1 INTO MODEL 2) h: ", second_run_h)
	print("Output shape of (SENDING H FROM MODEL 1 INTO MODEL 2) h: ", second_run_h.shape)

	print("Output of (SENDING H FROM MODEL 1 INTO MODEL 2) c: ", second_run_c)
	print("Output shape of (SENDING H FROM MODEL 1 INTO MODEL 2) c: ", second_run_c.shape)



	return


if __name__ == '__main__':
	main()