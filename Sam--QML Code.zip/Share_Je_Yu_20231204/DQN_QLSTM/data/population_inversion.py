import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn 
from torch.autograd import Variable
import torch.optim as optim




def DQ2(nbar, nmax, t):
	result = 0.
	for n in range(nmax+1):
		result += np.exp(-nbar)*nbar**n/np.math.factorial(n)*np.cos(2.*np.sqrt(n+1)*t)
	return result
	

def geenrateDQ2(t_length):
	time = np.arange(0, t_length, 0.1)
	data = np.zeros_like(time)
	for i, t in enumerate(time):
		data[i] = DQ2(10, 100, t)
	return time, data


def transform_data_single_predict(data, seq_length):
	x = []
	y = []

	for i in range(len(data)-seq_length-1):
		_x = data[i:(i+seq_length)]
		_y = data[i+seq_length]
		x.append(_x)
		y.append(_y)
	x_var = Variable(torch.from_numpy(np.array(x).reshape(-1, seq_length)).float())
	y_var = Variable(torch.from_numpy(np.array(y)).float())

	return x_var, y_var

def get_population_inversion_data(data = None, seq_len = 10):
	return transform_data_single_predict(data = data, seq_length = seq_len)


def main():
	time, data = geenrateDQ2(t_length = 200)
		
	plt.plot(time,data)
	plt.show()

	print(data)

	x_var, y_var = get_population_inversion_data(data = data)
	print(x_var.size())
	print(y_var.size())

	return


if __name__ == '__main__':
	main()
