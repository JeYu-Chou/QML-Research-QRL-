import numpy as np
import scipy.special
import matplotlib.pyplot as plt
import pickle

import torch
import torch.nn as nn 
from torch.autograd import Variable
import torch.optim as optim

from sklearn.preprocessing import MinMaxScaler

# import os
# import sys
# os.chdir(os.path.dirname(sys.argv[0]))

# create a figure window
# fig = plt.figure(1, figsize=(9,8))

# # create arrays for a few Bessel functions and plot them
# x = np.linspace(2, 100, 256)
# j0 = scipy.special.jn(0, x)
# j1 = scipy.special.jn(1, x)
# j2 = scipy.special.jn(2, x)
# y0 = scipy.special.yn(0, x)
# y1 = scipy.special.yn(1, x)
# y2 = scipy.special.yn(2, x)

# load NARMA2 data
# 2022 07 18: Path for calling from parent directory
with open('data/input_sequence_NARMA.pickle','rb') as f:
	input_sequence = pickle.load(f)
with open('data/target_sequence_NARMA.pickle','rb') as f:
	target_sequence = pickle.load(f)



# def generate_dataset(data_src = j0):
# 	# normalize the dataset
# 	scaler = MinMaxScaler(feature_range=(-1, 1))
# 	scaled_dataset = scaler.fit_transform(data_src.reshape(-1, 1))
# 	return scaled_dataset 

def transform_data_single_predict(data_input, data_target, seq_length):
	'''
	data_input: time series
	data_target: time series
	'''
	x = []
	y = []

	assert(len(data_input) == len(data_target))
	data_len = len(data_input)
	for i in range(data_len - seq_length-1):
		_x = data_input[i:(i+seq_length)]
		_y = data_target[i+seq_length]
		x.append(_x)
		y.append(_y)
	x_var = Variable(torch.from_numpy(np.array(x).reshape(-1, seq_length)).float())
	y_var = Variable(torch.from_numpy(np.array(y)).float())

	return x_var, y_var

def get_narma2_data(seq_len = 4):
	# scaled_dataset = generate_dataset(data)
	return transform_data_single_predict(data_input = input_sequence, data_target = target_sequence, seq_length = seq_len)

def plotting_test(data_input, data_target):
	ax1 = fig.add_subplot()
	ax1.plot(data_input)
	ax1.plot(data_target)

	ax1.axhline(color="grey", ls="--", zorder=-1)
	# ax1.set_ylim(-1,1)
	ax1.text(0.5, 0.95,'NARMA2', ha='center', va='top',
		 transform = ax1.transAxes)

	plt.show()

def main():
	plotting_test(data_input = input_sequence, data_target = target_sequence)
	x, y = get_narma2_data(seq_len = 4)
	print(x)
	print(y)

	print(x.shape)
	print(y.shape)

	

if __name__ == '__main__':
	main()
