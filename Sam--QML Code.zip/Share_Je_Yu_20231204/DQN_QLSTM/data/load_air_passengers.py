import os

import pandas
import matplotlib.pyplot as plt
import numpy as np 

import torch
import torch.nn as nn 
from torch.autograd import Variable
import torch.optim as optim

from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error

dataframe = pandas.read_csv(os.path.join(os.path.dirname(__file__), 'airline-passengers.csv'), usecols=[1], engine='python')


dataset = dataframe.values
dataset = dataset.astype('float32')

# print("Air assengers: ", dataset)

# normalize the dataset
scaler = MinMaxScaler(feature_range=(0, 1))
dataset = scaler.fit_transform(dataset)

# plt.plot(dataset)
# plt.show()

# split into train and test sets
train_size = int(len(dataset) * 0.67)
test_size = len(dataset) - train_size
train, test = dataset[0:train_size,:], dataset[train_size:len(dataset),:]
# print(len(train), len(test))


def create_dataset(dataset, look_back=1):
	dataX, dataY = [], []
	for i in range(len(dataset)-look_back-1):
		a = dataset[i:(i+look_back), 0]
		dataX.append(a)
		dataY.append(dataset[i + look_back, 0])
	return np.array(dataX), np.array(dataY)


# reshape into X=t and Y=t+1
look_back = 1
trainX, trainY = create_dataset(train, look_back)
testX, testY = create_dataset(test, look_back)

train_x = trainX.reshape(trainX.size,)
train_y = trainY

pred_step = 2

def transform_data(arr, seq_len):
	x, y = [], []
	for i in range(len(arr) - seq_len - (pred_step - 1)):
		x_i = arr[i : i + seq_len]
		y_i = arr[i + pred_step : i + seq_len + pred_step]
		x.append(x_i)
		y.append(y_i)
	x_arr = np.array(x).reshape(-1, seq_len)
	y_arr = np.array(y).reshape(-1, seq_len)
	x_var = Variable(torch.from_numpy(x_arr).float())
	y_var = Variable(torch.from_numpy(y_arr).float())
	return x_var, y_var

def transform_data_single_predict(data, seq_length):
	x = []
	y = []

	for i in range(len(data)-seq_length-1):
		_x = data[i:(i+seq_length)]
		_y = data[i+seq_length]
		x.append(_x)
		y.append(_y)
	x_var = Variable(torch.from_numpy(np.array(x).reshape(-1, seq_length)).float())
	y_var = Variable(torch.from_numpy(np.array(y)).float())

	return x_var, y_var

def get_air_passenger_data(dataset = train_x, seq_len = 10):
	return transform_data(dataset, seq_len)

def get_air_passenger_data_single_predict(dataset = dataset, seq_len = 4):
	return transform_data_single_predict(data = dataset, seq_length = seq_len)

x, y = get_air_passenger_data_single_predict()

print(x)
print(y)


print(x.size())
print(y.size())

x, y = get_air_passenger_data()

print(x)
print(y)


print(x.size())
print(y.size())

