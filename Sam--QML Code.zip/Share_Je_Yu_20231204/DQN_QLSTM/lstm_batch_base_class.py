# 2022 08 24
# QLSTM Batch version
# Idea: QLSTM with PyTorch compatible interface


# Plotting
import matplotlib.pyplot as plt

# Saving
import pickle

# Datetime
from datetime import datetime

# PyTorch
import torch
import torch.nn as nn
import torch.optim as optim
# from torch.optim import lr_scheduler
# import torchvision
# from torchvision import datasets, models, transforms

# Pennylane
import pennylane as qml
from pennylane import numpy as np

# sklearn
from sklearn.preprocessing import StandardScaler

# Other tools
import time
import os
import copy

# from VQC_GRAD_META_CONSTRUCT import load_JET_4_var_two

from metaquantum.CircuitComponents import *
from metaquantum import Optimization

# Qiskit
import qiskit
import qiskit.providers.aer.noise as noise

# Custom qiskit noise model
from ibm_noise_models import thermal_noise_backend, combined_error_noisy_backend, combined_noise_backend_normdist


# Dataset
# from generate_lstm_dataset import get_sine_data
# from data.load_air_passengers import get_air_passenger_data_single_predict
# from data.damped_shm import get_damped_shm_data
from data.bessel_functions import get_bessel_data
# from data.delayed_quantum_control import get_delayed_quantum_control_data
# from data.population_inversion_revised import get_population_inversion_data
# from generate_lstm_dataset import get_sine_data_single_predict
# from data.narma_data_set import get_narma2_data
# from data.narma_generator import get_narma_data


# QLSTM base
from lstm_base_class import VQLSTM




class BatchVQLSTM(nn.Module):
	def __init__(self, vqlstm_model):

		super().__init__()

		self.model = vqlstm_model

		return

	def forward(self, batch_x, initial_h, initial_c):
		'''
		batch_x: (N, L, D)
			N: batch size
			L: sequence length
			D: feature dimension

		initial_h: (1, N, D)
		1: single LSTM layer
		N: batch size
		D: feature dimension

		initial_c: (1, N, D)
		1: single LSTM layer
		N: batch size
		D: feature dimension
		'''

		batch_size = batch_x.shape[0]
		seq_len = batch_x.shape[1]
		x_feature_size = batch_x.shape[2]

		final_h = []
		final_c = []

		h_for_all_steps = []

		for idx in range(batch_size):
			res_h, res_c = self.model.forward(batch_x[idx].reshape(seq_len, x_feature_size), initial_h[0][idx], initial_c[0][idx])
			final_h.append(res_h[-1])
			final_c.append(res_c[-1])
			h_for_all_steps.append(res_h)
			# print("RES: ", res[-1])

		# 2022 08 23
		# The following 0 is temporary, which is to fit the PyTorch RNN interface

		# 2022 08 24
		# The x, (h, c) not x, h, c output form is to be fitted what PyTorch does.

		# 2022 08 25
		# The x position will we the h for all time-steps which can be processed further to generate x.
		# This is different from classical PyTorch.
		return torch.stack(h_for_all_steps), (torch.stack(final_h).unsqueeze(0), torch.stack(final_c).unsqueeze(0))






def main():


	# Force to use CPU
	dtype = torch.DoubleTensor
	device = 'cpu'


	qdevice = "default.qubit" # 2022 07 21: Should be depreciated later
	# qdevice = "qulacs.simulator"

	# gpu_q = True
	gpu_q = False

	##
	duplicate_time_of_input = 1

	lstm_input_size = 1
	lstm_hidden_size = 3
	lstm_cell_cat_size = lstm_input_size + lstm_hidden_size
	lstm_internal_size = 4
	lstm_output_size = 4  # 2022 07 07: the output here is subject to classical layer precessing
	lstm_cell_num_layers = 4 # Original: 2 layers
	lstm_num_qubit = 4

	as_reservoir = False
	# 2022 07 12: switch for reservoir -> if True, then the QRNN parameters will not be updated


	# 2022 07 21
	# Adding Qiskit noise simulation
	use_qiskit_noise_model = False

	dev = None

	if use_qiskit_noise_model:
		# Call the noise model
		noise_model = combined_noise_backend_normdist(num_qubits = lstm_num_qubit)
		dev = qml.device('qiskit.aer', wires=lstm_num_qubit, noise_model=noise_model)

	else:
		dev = qml.device("default.qubit", wires = lstm_num_qubit)
	
	model = VQLSTM(lstm_input_size = lstm_input_size, 
		lstm_hidden_size = lstm_hidden_size,
		lstm_output_size = lstm_output_size,
		lstm_num_qubit = lstm_num_qubit,
		lstm_cell_cat_size = lstm_cell_cat_size,
		lstm_cell_num_layers = lstm_cell_num_layers,
		lstm_internal_size = lstm_internal_size,
		duplicate_time_of_input = duplicate_time_of_input,
		as_reservoir = as_reservoir,
		single_y = False,
		output_all_h = True,
		qdevice = qdevice,
		dev = dev,
		gpu_q = gpu_q).double()

	# Test single input
	test_input_sequence = torch.randn(10,)
	h_0 = torch.zeros(lstm_hidden_size,).type(dtype)
	c_0 = torch.zeros(lstm_internal_size,).type(dtype)

	res_lstm_h, res_lstm_c = model.forward(test_input_sequence.reshape(10, 1), h_0, c_0)

	print("OUTPUT (h) SINGLE NON-BATCH SEQUENCE X: ", res_lstm_h)
	print("OUTPUT (c) SINGLE NON-BATCH SEQUENCE X: ", res_lstm_c)

	# Wrapped VQRNN into batch version

	batch_model = BatchVQLSTM(vqlstm_model = model)

	# Print model params
	print(batch_model.state_dict())

	# Test Cases

	N = 20
	L = 10
	D = 1

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)

	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)
	print("OUTPUT BATCH SEQUENCE X (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (h) SHAPE: ", res_batch_QLSTM_h.shape)
	print("OUTPUT BATCH SEQUENCE X (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (c) SHAPE: ", res_batch_QLSTM_c.shape)

	# Single input in a batch form
	N = 1
	L = 1
	D = 1

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)
	
	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (h) SHAPE: ", res_batch_QLSTM_h.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (c) SHAPE: ", res_batch_QLSTM_c.shape)

	# Single input in a batch form
	N = 1
	L = 10
	D = 1

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)
	
	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (h) SHAPE: ", res_batch_QLSTM_h.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (c) SHAPE: ", res_batch_QLSTM_c.shape)


	# Single input in a batch form
	N = 1
	L = 100
	D = 1

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)
	
	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (h) SHAPE: ", res_batch_QLSTM_h.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (c) SHAPE: ", res_batch_QLSTM_c.shape)


	# Next, we need to test multi-dimensional input (for RL use).

	print("\n\n\n=====TEST MULTI-DIMENSIONAL INPUT (for RL purpose)=====\n\n\n")

	lstm_input_size = 4
	lstm_hidden_size = 4
	lstm_cell_cat_size = lstm_input_size + lstm_hidden_size
	lstm_internal_size = 8
	lstm_output_size = 4  # 2022 07 07: the output here is subject to classical layer precessing
	lstm_cell_num_layers = 2 # Original: 2 layers
	lstm_num_qubit = 8


	# Re-initialize the dev

	dev = qml.device("default.qubit", wires = lstm_num_qubit)


	model = VQLSTM(lstm_input_size = lstm_input_size, 
		lstm_hidden_size = lstm_hidden_size,
		lstm_output_size = lstm_output_size,
		lstm_num_qubit = lstm_num_qubit,
		lstm_cell_cat_size = lstm_cell_cat_size,
		lstm_cell_num_layers = lstm_cell_num_layers,
		lstm_internal_size = lstm_internal_size,
		duplicate_time_of_input = duplicate_time_of_input,
		as_reservoir = as_reservoir,
		single_y = False,
		output_all_h = True,
		qdevice = qdevice,
		dev = dev,
		gpu_q = gpu_q).double()


	# Test single input

	test_input_sequence = torch.randn(10,4)
	h_0 = torch.zeros(lstm_hidden_size,).type(dtype)
	c_0 = torch.zeros(lstm_internal_size,).type(dtype)

	res_lstm_h, res_lstm_c = model.forward(test_input_sequence.reshape(10, 4), h_0, c_0)

	print("OUTPUT (h) SINGLE NON-BATCH SEQUENCE X: ", res_lstm_h)
	print("OUTPUT (c) SINGLE NON-BATCH SEQUENCE X: ", res_lstm_c)


	# Wrapped VQRNN into batch version

	batch_model = BatchVQLSTM(vqlstm_model = model)

	# Print model params
	print(batch_model.state_dict())

	# Test Cases

	N = 20
	L = 10
	D = 4

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)

	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)

	print("OUTPUT BATCH SEQUENCE X (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (h) SHAPE: ", res_batch_QLSTM_h.shape)
	print("OUTPUT BATCH SEQUENCE X (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (c) SHAPE: ", res_batch_QLSTM_c.shape)

	

	# Single input in a batch form
	N = 1
	L = 1
	D = 4

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)
	
	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (h) SHAPE: ", res_batch_QLSTM_h.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 1) (c) SHAPE: ", res_batch_QLSTM_c.shape)



	# Single input in a batch form
	N = 1
	L = 10
	D = 4

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)
	
	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (h) SHAPE: ", res_batch_QLSTM_h.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 10) (c) SHAPE: ", res_batch_QLSTM_c.shape)


	# Single input in a batch form
	N = 1
	L = 100
	D = 4

	test_input_sequence_batch = torch.randn(N, L, D)
	h_0_batch = torch.zeros(1, N, lstm_hidden_size).type(dtype)
	c_0_batch = torch.zeros(1, N, lstm_internal_size).type(dtype)
	
	h_for_all_steps, (res_batch_QLSTM_h, res_batch_QLSTM_c) = batch_model.forward(test_input_sequence_batch, h_0_batch, c_0_batch)

	print("OUTPUT BATCH SEQUENCE (h for all time-steps): ", h_for_all_steps.shape)
	
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (h): ", res_batch_QLSTM_h)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (h) SHAPE: ", res_batch_QLSTM_h.shape)

	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (c): ", res_batch_QLSTM_c)
	print("OUTPUT BATCH SEQUENCE X (BATCH_SIZE = 1 and SEQ_LEN = 100) (c) SHAPE: ", res_batch_QLSTM_c.shape)

	return


if __name__ == '__main__':
	main()












