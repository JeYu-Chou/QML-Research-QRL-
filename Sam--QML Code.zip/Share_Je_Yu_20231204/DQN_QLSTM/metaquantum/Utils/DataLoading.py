

# MNIST data (binary)




# Function Approximator